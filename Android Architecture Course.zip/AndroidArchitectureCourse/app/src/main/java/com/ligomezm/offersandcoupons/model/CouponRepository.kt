package com.ligomezm.offersandcoupons.model

interface CouponRepository {
    fun getCouponsAPI()
}